package com.company;

import java.util.ArrayList;

public abstract class Furniture {
    private String color;
    private int weight;

    public Furniture(String color, int weight){
        this.color=color;
        this.weight=weight;
    }

    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }

    public int getWeight() {
        return weight;
    }
    public void setWeight(int weight) {
        this.weight = weight;
    }
    public abstract String toString();
}
class Cupboard extends Furniture {
    private String width;
    private String height;
    private String depth;

    public Cupboard(String color, int weight, String width, String height, String depth) {
        super(color, weight);
        this.width = width;
        this.height = height;
        this.depth = depth;
    }

    public String getWidth() {
        return width;
    }
    public void setWidth(String width) {
        this.width = width;
    }

    public String getHeight() {
        return height;
    }
    public void setHeight(String height) {
        this.height = height;
    }

    public String getDepth() {
        return depth;
    }
    public void setDepth(String depth) {
        this.depth = depth;
    }

    public String toString() {
        return ("шкаф цвета: "+getColor()+" веса: "+getWeight()+" ширины: "+getWidth()+" высоты: "+getHeight()+" глубины: "+getHeight());
    }
}

class Nightstand extends Furniture {
    private int boxes;
    private int area;

    public Nightstand(String color, int weight, int boxes, int area) {
        super(color, weight);
        this.boxes = boxes;
        this.area = area;
    }

    public int getBoxes() {
        return boxes;
    }
    public void setBoxes(int boxes) {
        this.boxes = boxes;
    }

    public int getArea() {
        return area;
    }
    public void setArea(int area) {
        this.area = area;
    }

    public String toString() {
        return ("тумбочка цвета: "+getColor()+" веса: "+getWeight()+" кол-во ящиков: "+getBoxes()+" площадь рабочей поверхности: "+getArea());
    }
}


