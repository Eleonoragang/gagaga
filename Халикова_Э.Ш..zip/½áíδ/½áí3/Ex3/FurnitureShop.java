package com.company;

public class FurnitureShop {
    public static void main(String[] args) {
        Furniture cupboard = new Cupboard("white", 5 ,"2 m","4 m", "1 m");
        System.out.println(cupboard);
        Furniture nightstand = new Nightstand("blue", 4,6,10);
        System.out.println(nightstand);
    }
}
