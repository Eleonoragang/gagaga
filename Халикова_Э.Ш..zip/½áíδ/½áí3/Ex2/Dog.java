package com.company;

public abstract class Dog {
    private String name, size;
    private int age;

    public Dog(String name, int age, String size){
        this.name=name;
        this.age=age;
        this.size=size;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }

    public String getSize() {
        return size;
    }
    public void setSize(String size) {
        this.size = size;
    }

    public abstract String toString();
}

class Poodle extends Dog {
    public Poodle(String name, int age, String size) {
        super(name, age,size);
    }

    public String toString() {
        return (getName() + " породы пудель " + "возраст: " + getAge()+" years " + " размер: " + getSize() + " выступает в цирке ");
    }
}

class Doberman extends Dog{
    public Doberman(String name, int age, String size){
        super(name, age,size);
    }
    public String toString() {
        return (getName() + " породы Доберман " + "возраст: " + getAge()+" years " + " размер: " + getSize() + " служебная собака ");
    }
}
