package com.company;

public class TestDog {
    public static void main(String[] args) {
        Dog poodle = new Poodle("Richard", 5, "small");
        System.out.println(poodle);

        Dog doberman = new Doberman("Halk", 3, "big");
        System.out.println(doberman);

    }
}
