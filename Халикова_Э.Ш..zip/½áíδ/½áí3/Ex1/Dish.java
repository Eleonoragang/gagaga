package com.company;

// абстрактный класс фигуры
    public abstract class Dish {
        private String color;
        private String size;

    public Dish(String color, String size) {
        this.color = color;
        this.size = size;
        }

    public void setColor(String color) {
        this.color = color;
        }

    public void setSize(String size) {
        this.size = size;
        }

    public String getColor() {
        return color;
    }
    public String getSize() {
        return size;
    }

    public abstract String toString();

}
// производный класс тарелка
    class  Plant extends Dish{
        private String act;

    public Plant(String color, String size,String act){
        super(color,size);
        this.act=act;
        }

    public String getAct() {
        return act;
        }
    public void setAct(String act) {
        this.act = act;
        }

    public String  toString(){
        return ("тарелка: цвет: "+getColor()+" размер: "+getSize()+" применение: "+getAct());
        }
    }

    class Cup extends Dish{
        private int ml;

        public Cup(String color, String size, int ml){
            super(color, size);
            this.ml=ml;
        }

        public void setMl(int ml) {
            this.ml = ml;
        }
        public int getMl() {
            return ml;
        }

        public String toString(){
            return ("кружка: цвет: "+ getColor()+" размер: "+ getSize()+" объем: "+getMl());
        }
    }
