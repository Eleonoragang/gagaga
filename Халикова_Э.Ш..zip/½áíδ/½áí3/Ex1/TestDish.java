package com.company;

public class TestDish {
    public static void main(String[] args) {
        Dish  cup = new Cup("red","large", 550);
        System.out.println(cup);

        Dish plant = new Plant("white","small", "for pie");
        System.out.println(plant);
    }
}